"# Servicios"


Se implementaron las funciones sin y sqrt en donde
reciven la funcion y el numero y retorna el resultado

![](img/sqrt.PNG)
![](img/SIN.PNG)
